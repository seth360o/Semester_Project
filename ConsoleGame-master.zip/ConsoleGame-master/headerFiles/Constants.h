#pragma once

const int MAPHEIGHT = 5;
const int MAPWIDTH = 5;